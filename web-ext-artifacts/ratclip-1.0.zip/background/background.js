// import { copyToClipboard } from './content-script';

console.log('WebExtension initialised.');

browser.pageAction.onClicked.addListener((tab) => {
	console.clear();
	console.log('tab information:', tab);
	handleAsync();
});

async function handleAsync() {
	try {
		const tabsInfo = await browser.tabs.query({ active: true });
		if (!tabsInfo.length > 0) {
			console.log(`there are currently no active tabs`);
		}

		const activeTab = tabsInfo.pop();
		const address = { title: activeTab.title, url: activeTab.url };
		console.log(`tab address: [${address.title}: ${address.url}]`);

		// browser.tabs.sendMessage(activeTab.id, address); // '../content/content-script'

		await copy(activeTab.title, activeTab.url).then((r) =>
			console.log('copyToClipboard response:', r)
		);
	} catch (ex) {
		console.error('run error:', ex);
	}
}

/**
 * Copy current tab url as a hyperlink to the clipboard
 * @param {string} title
 * @param {string} url
 * @returns {HTMLAnchorElement} anchorElement
 */
async function copy(title, url) {
	try {
		const anchor = document.createElement('a');
		anchor.href = url;
		anchor.title = title;
		anchor.text = title;

		let items = [
			new ClipboardItem({
				['text/html']: new Blob([anchor.outerHTML]),
				['text/plain']: new Blob([anchor.title]),
			}),
		];
		await navigator.clipboard.write(items);
		return anchor;
	} catch (ex) {
		console.error('ratclip exception:', ex.name, ex.message);
	}
}
