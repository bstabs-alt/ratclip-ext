/**
 * Copy current tab url as a hyperlink to the clipboard
 * @param {string} title
 * @param {string} url
 * @returns {HTMLAnchorElement} anchorElement
 */
export async function copyToClipboard(title, url) {
	try {
		const anchor = document.createElement('a');
		anchor.title = title;
		anchor.href = url;

		let items = [
			new ClipboardItem({
				['text/html']: new Blob([anchor.outerHTML]),
				['text/plain']: new Blob([anchor.href]),
			}),
		];
		await navigator.clipboard.write(items);
		return anchor;
	} catch (ex) {
		console.error('ratclip exception:', ex.name, ex.message);
	}
}
